rm -rf node_modules/svgcanvas
ln -sf $(pwd)/../svgcanvas $(pwd)/node_modules/svgcanvas