var constants = {
    SVG: 'svg'
};

export default constants;
